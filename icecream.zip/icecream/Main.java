package org.example.tutorial.decorator.icecream;

public class Main {
    public static void main(String[] args) {
        Icecream icecream = new BaseIcecream();
        System.out.println(icecream.makeIcecream());
        Icecream icecream1 = new HoneyDecorator((new BaseIcecream()));
        System.out.println(icecream1.makeIcecream());
        Icecream icecream2 = new HoneyDecorator(new FruitDecorator(new BaseIcecream()));
        System.out.println(icecream2.makeIcecream());
    }
}
