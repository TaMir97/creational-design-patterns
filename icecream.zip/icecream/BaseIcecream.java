package org.example.tutorial.decorator.icecream;

public class BaseIcecream implements Icecream{
    @Override
    public String makeIcecream() {
        return "Base Ice cream";
    }
}
