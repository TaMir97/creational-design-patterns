package org.example.tutorial.decorator.icecream;

public class HoneyDecorator extends IcecreamDecorator{
    public HoneyDecorator(Icecream specialIcecream) {
        super(specialIcecream);
    }
    public String makeIcecream(){
        return super.makeIcecream() + addHoney();
    }
    private String addHoney(){
        return " + Honey";
    }
}
