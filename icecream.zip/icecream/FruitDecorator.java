package org.example.tutorial.decorator.icecream;

public class FruitDecorator extends IcecreamDecorator{
    public FruitDecorator(Icecream specialIcecream) {
        super(specialIcecream);
    }
    public String makeIcecream(){
        return super.makeIcecream() + addFruit();
    }
    private String addFruit(){
        return " + Fruit";
    }
}
