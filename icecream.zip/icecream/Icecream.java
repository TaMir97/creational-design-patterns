package org.example.tutorial.decorator.icecream;

public interface Icecream {
     String makeIcecream();
}
